from .utility cimport pair
